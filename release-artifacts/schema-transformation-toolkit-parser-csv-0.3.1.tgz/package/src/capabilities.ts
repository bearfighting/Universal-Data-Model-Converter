import type { ParserCapabilities } from "@schema-transformation-toolkit/core";

export const csvParserCapabilities: ParserCapabilities = {
  format: "csv",
  producesIr: ["value", "shape"],
  outputs: [{ ir: "value", valueRootKinds: ["array"] }, { ir: "shape" }],
  capabilities: ["value-ir", "shape-ir"],
  valueRootKinds: ["array"],
};
