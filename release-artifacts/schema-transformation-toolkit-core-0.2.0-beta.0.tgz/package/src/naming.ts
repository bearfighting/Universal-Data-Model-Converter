export {
  capitalizeWord,
  createNamingStrategy,
  getRenderableWords,
  normalizeIdentifier,
  renderIdentifierName,
  toCamelCase,
  toPascalCase,
  toSnakeCase,
} from "./shared/naming.js";

export type {
  NamingStrategy,
  NamingStrategyOptions,
  NamingStyle,
  RenderIdentifierOptions,
} from "./shared/naming.js";
